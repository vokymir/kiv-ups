POZOR: ve vypiskach chybi priblizne prvni dve prezentace

Jak jsem se ucil ja:
 - prosel jsem si jenom jednou vsechny prezentace: k tomu je pdf *ups_prednasky_kapitoly*
 - napsal jsem si poznámky (ty už máš vyfocený)
 - několikrát jsem si je prošel

 Mě stejně nejvíc pomohlo napsat si ty poznámky, tak doporučuju aspoň část přepsat.

 BONUS: *communication_overview* z Úblovo posledniho cvičení,
 co všechno se musí stát, než se načte webová stránka.

 Snad alespoň nějaký poznámky přečteš, psal jsem to jenom pro sebe,
 tak to občas může být kryptický...
